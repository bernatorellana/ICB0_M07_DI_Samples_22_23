﻿
using System;
using DemoTestingUnitari.Model;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestProject
{
    [TestClass]
    public class TarifaTest
    {
        [TestMethod]
        public void kkkk()
        {

            /// <summary>
            /// Calcula el preu de l'entrada.
            ///  - jubilats: gratuït
            ///  - menors: 10€
            ///  - public general: 20€
            /// </summary>
            /// <param name="edat">L'edat. Ha d'estar entre 3 i 120 (inclosos) anys.
            /// Altrament llança excepció.</param>
            /// <returns>el preu de l'entrada</returns>

            /*
            // -1
            //Assert.AreEqual(  )
            //  2
            //  3
            Assert.AreEqual(10, Tarifes.getPreu(3));
            // 15
            Assert.AreEqual(10, Tarifes.getPreu(15));
            // 17
            Assert.AreEqual(10, Tarifes.getPreu(17));
            // 18
            Assert.AreEqual(20, Tarifes.getPreu(18));
            // 45
            Assert.AreEqual(20, Tarifes.getPreu(45));
            // 64
            Assert.AreEqual(20, Tarifes.getPreu(64));
            // 65
            Assert.AreEqual(0, Tarifes.getPreu(65));
            // 80
            Assert.AreEqual(0, Tarifes.getPreu(80));
            // 120
            // 121

            Assert.AreEqual(0, 0);*/
        }
    }
}
