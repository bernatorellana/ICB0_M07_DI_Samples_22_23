﻿using DBLib;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// La plantilla de elemento Página en blanco está documentada en https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0xc0a

namespace AppAmbBD
{
    /// <summary>
    /// Página vacía que se puede usar de forma independiente o a la que se puede navegar dentro de un objeto Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            List<EmpDB> empleats = EmpDB.getEmpleats("", null);
            grdDades.ItemsSource = empleats;

            /*foreach( EmpDB em in empleats)
            {
                txbResultat.Text += em.Emp_no + " " + em.Cognom;
            }*/
        }

        private void btnFiltre_Click(object sender, RoutedEventArgs e)
        {
            cerca();
        }

        private void cerca()
        {
            DateTime? dataFiltre = null;
            try
            {
                dataFiltre = DateTime.ParseExact(
                                txbFiltreData.Text,
                                "dd/MM/yyyy",
                                System.Globalization.CultureInfo.InvariantCulture);
            }
            catch (Exception ex) { }


            grdDades.ItemsSource = EmpDB.getEmpleats(txbFiltreNom.Text, dataFiltre);
        }

        private void btnClearFiltre_Click(object sender, RoutedEventArgs e)
        {
            txbFiltreData.Text = "";
            txbFiltreNom.Text = "";
            cerca();

        }

        private void btnEsborrar_Click(object sender, RoutedEventArgs e)
        {
            if (grdDades.SelectedItem != null)
            {

                EmpDB empleat = (EmpDB) grdDades.SelectedItem;

                EmpDB.delete(empleat.Emp_no);
            }
        }
    }
}
