﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;


namespace DBLib
{
    public class EmpDB
    {
        private int emp_no;
        private String cognom;
        private String ofici;
        private int? cap;
        private DateTime? data_alta;
        private decimal? salari;
        private decimal? comissio;
        private int dept_no;

        public EmpDB(int emp_no, string cognom, string ofici, int? cap, DateTime? data_alta, decimal? salari, decimal? comissio, int dept_no)
        {
            this.Emp_no = emp_no;
            this.Cognom = cognom;
            this.Ofici = ofici;
            this.Cap = cap;
            this.Data_alta = data_alta;
            this.Salari = salari;
            this.Comissio = comissio;
            this.Dept_no = dept_no;
        }
        #region properties
        public int Emp_no { get => emp_no; set => emp_no = value; }
        public string Cognom { get => cognom; set => cognom = value; }
        public string Ofici { get => ofici; set => ofici = value; }
        public int? Cap { get => cap; set => cap = value; }
        public DateTime? Data_alta { get => data_alta; set => data_alta = value; }
        public decimal? Salari { get => salari; set => salari = value; }
        public decimal? Comissio { get => comissio; set => comissio = value; }
        public int Dept_no { get => dept_no; set => dept_no = value; }
        #endregion


        /// <summary>
        /// Deletes the specified emp no.
        /// </summary>
        /// <param name="empNo">The emp no.</param>
        /// <returns></returns>
        public static Boolean delete(int empNo)
        {
            DbTransaction transaccio = null;
            try {
                using (MySQLDbContext context = new MySQLDbContext())
                {
                    using (var connection = context.Database.GetDbConnection())
                    {
                        connection.Open();

                        transaccio = connection.BeginTransaction();
                        using (var comanda = connection.CreateCommand())
                        {
                            
                            comanda.CommandText =
                                "delete from emp where emp_no=@p_emp_no";
                            //-----------------------------------------------
                            //    IMPORTANT !!! posem la comanda dins de la transacció
                            //-----------------------------------------------
                            comanda.Transaction = transaccio; //
                            //-----------------------------------------------
                            DBUtils.afegirParametre(comanda, "p_emp_no", empNo, DbType.Int32);
                            int liniesAfectades = comanda.ExecuteNonQuery();
                            if (liniesAfectades != 1)
                            {
                                transaccio.Rollback();
                                return true;
                            }
                            else
                            {
                                transaccio.Commit();
                            }
                        }
                    }
                }
             }catch(Exception ex)
            {
                Console.WriteLine("ERROR" + ex);
            }
            return false;
        }


        public static List<EmpDB> getEmpleats(
            String filtreCognom,
            DateTime? filterData) 
        {
            List<EmpDB> empleats = new List<EmpDB>();
            using(MySQLDbContext context = new MySQLDbContext())
            {
                using (var connection = context.Database.GetDbConnection())
                {
                    connection.Open();
                    using( var comanda = connection.CreateCommand())
                    {
                        comanda.CommandText = @"select * from emp 
                                                where (@p_nom='' or cognom like @p_nom ) and
                                                      (@p_data is null or data_alta>= @p_data) ";
                        DBUtils.afegirParametre(comanda, "p_nom", "%"+filtreCognom+"%", DbType.String);
                        DBUtils.afegirParametre(comanda, "p_data", filterData, DbType.DateTime);

                        DbDataReader reader = comanda.ExecuteReader();
                        while (reader.Read())
                        {
                            int emp_no = reader.GetInt32(reader.GetOrdinal("emp_no"));
                            String cognom = DBUtils.readDBC<String>(reader, "cognom");
                            string ofici = reader.GetString(reader.GetOrdinal("ofici"));
                            int? cap = DBUtils.readDB<Int32>(reader, "cap");
                            DateTime? dataAlta = DBUtils.readDB<DateTime>(reader, "data_alta");
                            decimal? salari = DBUtils.readDB<decimal>(reader, "salari");
                            decimal? comissio = DBUtils.readDB<decimal>(reader, "comissio");
                            int? dept_no = DBUtils.readDB<int>(reader, "dept_no");

                            EmpDB emp = new EmpDB(emp_no, cognom, ofici, cap, dataAlta,
                                salari, comissio, dept_no.Value);
                            empleats.Add(emp);
                        }
                    }
                }
            }
            return empleats;
        }
        
    }
}
